package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.client.util.InputUtil;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.random.Random;
import org.lwjgl.glfw.GLFW;

/**
 * Âm bàn phím cơ (Cherry MX) từ bộ ogg bạn đưa: mỗi phím một mẫu riêng, giống Creamy Keys.
 * "Toàn game": thay LUÔN tiếng của mọi thứ trong Minecraft (menu, cài đặt, chuột, đặt / phá block, bước chân, quái...) bằng tiếng phím.
 *   0 = tắt (chỉ tiếng khi gõ phím / bấm chuột), 1 = mọi tiếng giao diện (menu, nút, cài đặt...), 2 = mọi tiếng trong game (trừ nhạc).
 */
public class KeySound {
    static final boolean[] down = new boolean[350];
    static final boolean[] mdown = new boolean[3];
    /** thứ tự trùng với Mode "Loại" trong module KeySound (số cuối = Vanilla). */
    public static final String[] PACKS = {"brown_pbt", "brown_abs", "red_abs", "black_pbt", "black_abs", "blue_abs", "blue_abs_2"};
    public static final String[] PACK_NAMES = {"Brown PBT", "Brown ABS", "Red ABS", "Black PBT", "Black ABS", "Blue ABS", "Blue ABS 2", "Vanilla"};

    static SoundEvent ev(String pack, int n) { return SoundEvent.of(Identifier.of("safeanchor", "kb_" + pack + "_" + String.format("%02d", n))); }

    static int idxFor(int key) { return Math.floorMod(key * 7 + 3, 40) + 1; }

    static void play(MinecraftClient mc, int key, boolean release) {
        Config c = Config.I;
        float vol = Math.max(0f, Math.min(1f, c.keySoundVol / 100f));
        float pitch = (float) (c.keySoundPitch / 100.0) * (0.97f + (float) Math.random() * 0.06f);
        boolean big = key == GLFW.GLFW_KEY_SPACE || key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_BACKSPACE;
        if (big) pitch *= 0.85f;                                    // phím to nghe trầm hơn
        if (release) { pitch *= 1.25f; vol *= 0.45f; }
        pitch = Math.max(0.5f, Math.min(2.0f, pitch));
        if (c.keySoundType >= PACKS.length) {                       // Vanilla
            mc.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, pitch));
            return;
        }
        mc.getSoundManager().play(PositionedSoundInstance.master(ev(PACKS[c.keySoundType], idxFor(key)), pitch, vol));
    }

    /** Gọi từ SoundManagerMixin: thay tiếng game bằng tiếng phím. true = đã thay (hủy tiếng gốc). */
    public static boolean replace(SoundInstance s) {
        Config c = Config.I;
        if (!c.keySound || !c.enabled || c.keySoundAll <= 0 || c.keySoundType >= PACKS.length) return false;
        if (s == null || s.getId() == null || "safeanchor".equals(s.getId().getNamespace())) return false;
        SoundCategory cat = s.getCategory();
        if (cat == SoundCategory.MUSIC || cat == SoundCategory.RECORDS) return false;
        if (c.keySoundAll == 1 && cat != SoundCategory.MASTER) return false;
        MinecraftClient mc = MinecraftClient.getInstance();
        float vol = Math.max(0f, Math.min(1f, s.getVolume() * c.keySoundVol / 100f));
        float pitch = Math.max(0.5f, Math.min(2f, (float) (c.keySoundPitch / 100.0) * (0.95f + (float) Math.random() * 0.1f)));
        int n = 1 + (int) (Math.random() * 40);
        SoundEvent e = ev(PACKS[c.keySoundType], n);
        SoundInstance r = (s.isRelative() || s.getAttenuationType() == SoundInstance.AttenuationType.NONE)
                ? PositionedSoundInstance.master(e, pitch, vol)
                : new PositionedSoundInstance(e, cat, vol, pitch, Random.create(), s.getX(), s.getY(), s.getZ());
        mc.getSoundManager().play(r);
        return true;
    }

    public static void tick(MinecraftClient mc) {
        Config c = Config.I;
        if (!c.keySound || !c.enabled) return;
        long h = mc.getWindow().getHandle();
        for (int k = 32; k < 350; k++) {
            boolean d = InputUtil.isKeyPressed(h, k);
            if (d != down[k]) {
                down[k] = d;
                if (d) play(mc, k, false); else if (c.keySoundRelease) play(mc, k, true);
            }
        }
        for (int b = 0; b < 3; b++) {
            boolean d = GLFW.glfwGetMouseButton(h, b) == GLFW.GLFW_PRESS;
            if (d != mdown[b]) {
                mdown[b] = d;
                if (d) play(mc, 20 + b, false); else if (c.keySoundRelease) play(mc, 20 + b, true);
            }
        }
    }
}
